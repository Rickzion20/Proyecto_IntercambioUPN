# UPN Intercambio – Layouts XML (Android Studio Panda 2 · Java · Material 3)

## Cómo usarlo
1. Copia el contenido de `app/src/main/res/` dentro de tu proyecto (`app/src/main/res/`). No pisa tu `themes.xml` ni `strings.xml` (usa archivos `*_upn.xml`).
2. Tu tema debe ser Material 3 (el de la plantilla por defecto: `Theme.Material3.DayNight.NoActionBar`).
3. En `app/build.gradle(.kts)` verifica estas dependencias:
   - `com.google.android.material:material` (1.11 o superior)
   - `androidx.recyclerview:recyclerview`
4. Si tu `colors.xml` no trae `white`, agrega `<color name="white">#FFFFFF</color>`.

## Placeholders que debes reemplazar
- `drawable/logo_upn.xml`  → tu logo: agrega `logo_upn.png` y **borra** el .xml
- `drawable/bg_inicio.xml` → foto del campus: agrega `bg_inicio.png` y **borra** el .xml
- Las fotos de libros/avatares usan `ic_image` / `ic_person` como marcador; se cambian por código (Glide/Picasso o `setImageResource`).

## Notas
- `dialog_filtros` y `dialog_cerrar_sesion` son para `BottomSheetDialog` / `Dialog` (no Activity).
- Las listas son `RecyclerView` con `tools:listitem` (se ven en el Preview). Cada `item_*.xml` necesita su Adapter.
- Barra inferior: `layout_bottom_nav` (id `bottom_navigation`); marca la pestaña con `setSelectedItemId(R.id.nav_buscar)`, etc.
- Los textos están escritos directo para que veas el diseño; luego pásalos a `strings.xml` (Alt+Enter → Extract string resource).
