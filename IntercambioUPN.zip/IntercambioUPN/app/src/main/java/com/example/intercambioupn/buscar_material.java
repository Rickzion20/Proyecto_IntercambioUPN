package com.example.intercambioupn;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

import java.util.ArrayList;

public class buscar_material extends AppCompatActivity {

    private static final int REQUEST_FILTROS = 101;

    private EditText txtBuscarMaterial;
    private TextView txtMensajeResultados;
    private RecyclerView listaResultados;

    private ArrayList<Material> resultadosLista;
    private AdaptadorResultados adaptadorResultados;
    private RequestQueue rq;

    private String filtroCategoria = "";
    private String filtroCarrera = "";
    private String filtroTipo = "";
    private String filtroEstado = "";
    private String filtroSede = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_buscar_material);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtBuscarMaterial = findViewById(R.id.txtBuscarMaterial);
        txtMensajeResultados = findViewById(R.id.txtMensajeResultados);
        listaResultados = findViewById(R.id.listaResultados);

        resultadosLista = new ArrayList<>();
        rq = Volley.newRequestQueue(this);

        if (listaResultados != null) {
            listaResultados.setLayoutManager(new LinearLayoutManager(this));
            adaptadorResultados = new AdaptadorResultados();
            listaResultados.setAdapter(adaptadorResultados);
        }

        realizarBusqueda("");
    }

    public void regresar(View view) {
        finish();
    }

    public void abrirFiltros(View view) {
        Intent intent = new Intent(buscar_material.this, filtros.class);
        intent.putExtra("categoria", filtroCategoria);
        intent.putExtra("carrera", filtroCarrera);
        intent.putExtra("tipo", filtroTipo);
        intent.putExtra("estado", filtroEstado);
        intent.putExtra("sede", filtroSede);
        startActivityForResult(intent, REQUEST_FILTROS);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_FILTROS && resultCode == RESULT_OK && data != null) {
            filtroCategoria = data.getStringExtra("categoria") != null ? data.getStringExtra("categoria") : "";
            filtroCarrera = data.getStringExtra("carrera") != null ? data.getStringExtra("carrera") : "";
            filtroTipo = data.getStringExtra("tipo") != null ? data.getStringExtra("tipo") : "";
            filtroEstado = data.getStringExtra("estado") != null ? data.getStringExtra("estado") : "";
            filtroSede = data.getStringExtra("sede") != null ? data.getStringExtra("sede") : "";

            realizarBusqueda(txtBuscarMaterial.getText().toString());
        }
    }

    public void buscarMaterial(View view) {
        String query = txtBuscarMaterial.getText().toString().trim();
        realizarBusqueda(query);
    }

    private void realizarBusqueda(String query) {
        resultadosLista.clear();
        String q = query.toLowerCase();

        ArrayList<Material> base = MainActivity.listaMateriales != null ? MainActivity.listaMateriales : new ArrayList<>();

        for (Material m : base) {
            boolean coincideQuery = q.isEmpty() ||
                    m.getNombre().toLowerCase().contains(q) ||
                    m.getDescripcion().toLowerCase().contains(q);

            boolean coincideCategoria = filtroCategoria.isEmpty() ||
                    filtroCategoria.startsWith("Todas") ||
                    m.getCategoria().equalsIgnoreCase(filtroCategoria);

            boolean coincideCarrera = filtroCarrera.isEmpty() ||
                    filtroCarrera.startsWith("Todas") ||
                    m.getCarrera().equalsIgnoreCase(filtroCarrera);

            boolean coincideTipo = filtroTipo.isEmpty() ||
                    filtroTipo.startsWith("Todos") ||
                    m.getTipo().equalsIgnoreCase(filtroTipo);

            boolean coincideEstado = filtroEstado.isEmpty() ||
                    filtroEstado.startsWith("Todos") ||
                    m.getEstado().equalsIgnoreCase(filtroEstado);

            boolean coincideSede = filtroSede.isEmpty() ||
                    filtroSede.startsWith("Todas") ||
                    m.getSede().equalsIgnoreCase(filtroSede);

            if (coincideQuery && coincideCategoria && coincideCarrera && coincideTipo && coincideEstado && coincideSede) {
                resultadosLista.add(m);
            }
        }

        if (resultadosLista.isEmpty()) {
            if (txtMensajeResultados != null) {
                txtMensajeResultados.setVisibility(View.VISIBLE);
                txtMensajeResultados.setText("No se encontraron publicaciones que coincidan con la búsqueda.");
            }
        } else {
            if (txtMensajeResultados != null) {
                txtMensajeResultados.setVisibility(View.GONE);
            }
        }

        if (adaptadorResultados != null) {
            adaptadorResultados.notifyDataSetChanged();
        }
    }

    private class AdaptadorResultados extends RecyclerView.Adapter<AdaptadorResultados.ViewHolder> {

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new ViewHolder(
                    getLayoutInflater().inflate(
                            R.layout.item_publicacion_card,
                            parent,
                            false
                    )
            );
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return resultadosLista.size();
        }

        class ViewHolder extends RecyclerView.ViewHolder {

            TextView tvNombre;
            TextView tvTipo;
            TextView tvEstado;
            TextView tvSede;
            ImageView ivFoto;

            public ViewHolder(@NonNull View itemView) {
                super(itemView);

                tvNombre = itemView.findViewById(R.id.txtNombreMaterial);
                tvTipo = itemView.findViewById(R.id.txtTipo);
                tvEstado = itemView.findViewById(R.id.txtEstado);
                tvSede = itemView.findViewById(R.id.txtSede);
                ivFoto = itemView.findViewById(R.id.imgMaterial);

                itemView.setOnClickListener(v -> {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        Material material = resultadosLista.get(pos);
                        Intent intent = new Intent(buscar_material.this, item_publicacion.class);
                        intent.putExtra("id", material.getId());
                        intent.putExtra("nombre", material.getNombre());
                        intent.putExtra("descripcion", material.getDescripcion());
                        intent.putExtra("categoria", material.getCategoria());
                        intent.putExtra("tipo", material.getTipo());
                        intent.putExtra("estado", material.getEstado());
                        intent.putExtra("sede", material.getSede());
                        intent.putExtra("carrera", material.getCarrera());
                        intent.putExtra("foto", material.getFoto());
                        startActivity(intent);
                    }
                });
            }

            public void imprimir(int position) {
                Material material = resultadosLista.get(position);

                if (tvNombre != null) tvNombre.setText(material.getNombre());
                if (tvTipo != null) tvTipo.setText(material.getTipo());
                if (tvEstado != null) tvEstado.setText(material.getEstado());
                if (tvSede != null) tvSede.setText(material.getSede());

                if (ivFoto != null) {
                    recuperarImagen(material.getFoto(), ivFoto);
                }
            }

            public void recuperarImagen(String foto, ImageView iv) {
                if (foto == null || foto.trim().isEmpty()) {
                    iv.setImageResource(R.drawable.ic_launcher_foreground);
                    return;
                }

                ImageRequest peticion = new ImageRequest(
                        foto,
                        new Response.Listener<Bitmap>() {
                            @Override
                            public void onResponse(Bitmap response) {
                                iv.setImageBitmap(response);
                            }
                        },
                        0,
                        0,
                        ImageView.ScaleType.CENTER_CROP,
                        Bitmap.Config.RGB_565,
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                iv.setImageResource(R.drawable.ic_launcher_foreground);
                            }
                        }
                );

                rq.add(peticion);
            }
        }
    }
}
