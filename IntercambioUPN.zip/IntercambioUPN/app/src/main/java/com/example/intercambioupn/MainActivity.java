package com.example.intercambioupn;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    public static ArrayList<Material> listaMateriales;

    private RequestQueue rq;
    private RecyclerView recyclerPublicaciones;
    private AdaptadorMaterial adaptadorMaterial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        recyclerPublicaciones = findViewById(R.id.recyclerPublicaciones);

        listaMateriales = new ArrayList<>();
        rq = Volley.newRequestQueue(this);

        if (recyclerPublicaciones != null) {
            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            recyclerPublicaciones.setLayoutManager(linearLayoutManager);

            adaptadorMaterial = new AdaptadorMaterial();
            recyclerPublicaciones.setAdapter(adaptadorMaterial);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        cargarPublicaciones();
    }

    public void perfil(View view) {
        Intent intent = new Intent(MainActivity.this, perfil.class);
        startActivity(intent);
    }

    public void publicar(View view) {
        Intent intent = new Intent(MainActivity.this, publicar_material.class);
        startActivity(intent);
    }

    public void buscar(View view) {
        Intent intent = new Intent(MainActivity.this, buscar_material.class);
        startActivity(intent);
    }

    public void misPublicaciones(View view) {
        Intent intent = new Intent(MainActivity.this, mis_publicaciones.class);
        startActivity(intent);
    }

    private void cargarPublicaciones() {
        String url = "http://192.168.1.35:80/crud_intercambio/mostrar_.php";

        JsonObjectRequest requerimiento = new JsonObjectRequest(
                Request.Method.GET,
                url,
                null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("datos");
                            listaMateriales.clear();

                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject objeto = jsonArray.getJSONObject(i);

                                String id = objeto.optString("id", "");
                                String nombre = objeto.has("nombre_material") ? objeto.optString("nombre_material", "") : objeto.optString("nombre", "");
                                String descripcion = objeto.optString("descripcion", "");
                                String categoria = objeto.optString("categoria", "");
                                String tipo = objeto.optString("tipo", "");
                                String estado = objeto.optString("estado", "");
                                String sede = objeto.optString("sede", "");
                                String foto = objeto.optString("foto", "");

                                Material material = new Material(
                                        id,
                                        nombre,
                                        descripcion,
                                        categoria,
                                        tipo,
                                        estado,
                                        sede,
                                        foto
                                );

                                listaMateriales.add(material);
                            }

                            if (adaptadorMaterial != null) {
                                adaptadorMaterial.notifyDataSetChanged();
                            }

                        } catch (JSONException e) {
                            Toast.makeText(
                                    MainActivity.this,
                                    "Error al leer las publicaciones",
                                    Toast.LENGTH_SHORT
                            ).show();
                            e.printStackTrace();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(
                                MainActivity.this,
                                "Error al cargar publicaciones: " + error.toString(),
                                Toast.LENGTH_LONG
                        ).show();
                    }
                }
        );

        rq.add(requerimiento);
    }

    private class AdaptadorMaterial extends RecyclerView.Adapter<AdaptadorMaterial.AdaptadorMaterialHolder> {

        @NonNull
        @Override
        public AdaptadorMaterialHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new AdaptadorMaterialHolder(
                    getLayoutInflater().inflate(
                            R.layout.activity_item_publicacion,
                            parent,
                            false
                    )
            );
        }

        @Override
        public void onBindViewHolder(@NonNull AdaptadorMaterialHolder holder, int position) {
            holder.imprimir(position);
        }

        @Override
        public int getItemCount() {
            return listaMateriales.size();
        }

        class AdaptadorMaterialHolder extends RecyclerView.ViewHolder {

            TextView tvNombre;
            TextView tvDescripcion;
            TextView tvCategoria;
            TextView tvTipo;
            TextView tvEstado;
            TextView tvSede;
            ImageView ivFoto;

            public AdaptadorMaterialHolder(@NonNull View itemView) {
                super(itemView);

                tvNombre = itemView.findViewById(R.id.txtNombreMaterial);
                tvDescripcion = itemView.findViewById(R.id.txtDescripcion);
                tvCategoria = itemView.findViewById(R.id.txtCategoria);
                tvTipo = itemView.findViewById(R.id.txtTipo);
                tvEstado = itemView.findViewById(R.id.txtEstado);
                tvSede = itemView.findViewById(R.id.txtSede);
                ivFoto = itemView.findViewById(R.id.imgMaterial);

                itemView.setOnClickListener(v -> {
                    int pos = getAdapterPosition();
                    if (pos != RecyclerView.NO_POSITION) {
                        Material material = listaMateriales.get(pos);
                        Intent intent = new Intent(MainActivity.this, editar_publicacion.class);
                        intent.putExtra("id", material.getId());
                        intent.putExtra("nombre", material.getNombre());
                        intent.putExtra("descripcion", material.getDescripcion());
                        intent.putExtra("foto", material.getUrlimagen());
                        intent.putExtra("categoria", material.getCategoria());
                        intent.putExtra("tipo", material.getTipo());
                        intent.putExtra("estado", material.getEstado());
                        intent.putExtra("sede", material.getSede());
                        startActivity(intent);
                    }
                });
            }

            public void imprimir(int position) {
                Material material = listaMateriales.get(position);

                if (tvNombre != null) tvNombre.setText(material.getNombre());
                if (tvDescripcion != null) tvDescripcion.setText(material.getDescripcion());
                if (tvCategoria != null) tvCategoria.setText("Categoría: " + material.getCategoria());
                if (tvTipo != null) tvTipo.setText("Tipo: " + material.getTipo());
                if (tvEstado != null) tvEstado.setText(material.getEstado());
                if (tvSede != null) tvSede.setText(material.getSede());

                if (ivFoto != null) {
                    recuperarImagen(material.getUrlimagen(), ivFoto);
                }
            }

            public void recuperarImagen(String foto, ImageView iv) {
                if (foto == null || foto.trim().isEmpty()) {
                    iv.setImageResource(R.drawable.ic_launcher_foreground);
                    return;
                }

                ImageRequest peticion = new ImageRequest(
                        foto,
                        new Response.Listener<Bitmap>() {
                            @Override
                            public void onResponse(Bitmap response) {
                                iv.setImageBitmap(response);
                            }
                        },
                        0,
                        0,
                        ImageView.ScaleType.CENTER_CROP,
                        Bitmap.Config.RGB_565,
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                iv.setImageResource(R.drawable.ic_launcher_foreground);
                            }
                        }
                );

                rq.add(peticion);
            }
        }
    }
}
