package com.example.intercambioupn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class filtros extends AppCompatActivity {

    private Spinner spCategoria;
    private Spinner spCarrera;
    private Spinner spTipoIntercambio;
    private Spinner spEstadoMaterial;
    private Spinner spSede;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_filtros);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spCategoria = findViewById(R.id.spCategoria);
        spCarrera = findViewById(R.id.spCarrera);
        spTipoIntercambio = findViewById(R.id.spTipoIntercambio);
        spEstadoMaterial = findViewById(R.id.spEstadoMaterial);
        spSede = findViewById(R.id.spSede);

        Intent intent = getIntent();
        if (intent != null) {
            setSelectionIfPresent(spCategoria, intent.getStringExtra("categoria"));
            setSelectionIfPresent(spCarrera, intent.getStringExtra("carrera"));
            setSelectionIfPresent(spTipoIntercambio, intent.getStringExtra("tipo"));
            setSelectionIfPresent(spEstadoMaterial, intent.getStringExtra("estado"));
            setSelectionIfPresent(spSede, intent.getStringExtra("sede"));
        }
    }

    private void setSelectionIfPresent(Spinner spinner, String val) {
        if (spinner == null || val == null || val.isEmpty()) return;
        ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
        if (adapter != null) {
            for (int i = 0; i < adapter.getCount(); i++) {
                if (adapter.getItem(i).toString().equalsIgnoreCase(val)) {
                    spinner.setSelection(i);
                    break;
                }
            }
        }
    }

    public void regresar(View view) {
        finish();
    }

    public void aplicarFiltros(View view) {
        String cat = spCategoria != null && spCategoria.getSelectedItem() != null ? spCategoria.getSelectedItem().toString() : "";
        String car = spCarrera != null && spCarrera.getSelectedItem() != null ? spCarrera.getSelectedItem().toString() : "";
        String tip = spTipoIntercambio != null && spTipoIntercambio.getSelectedItem() != null ? spTipoIntercambio.getSelectedItem().toString() : "";
        String est = spEstadoMaterial != null && spEstadoMaterial.getSelectedItem() != null ? spEstadoMaterial.getSelectedItem().toString() : "";
        String sed = spSede != null && spSede.getSelectedItem() != null ? spSede.getSelectedItem().toString() : "";

        Intent result = new Intent();
        result.putExtra("categoria", cat);
        result.putExtra("carrera", car);
        result.putExtra("tipo", tip);
        result.putExtra("estado", est);
        result.putExtra("sede", sed);
        setResult(RESULT_OK, result);
        finish();
    }

    public void limpiarFiltros(View view) {
        if (spCategoria != null) spCategoria.setSelection(0);
        if (spCarrera != null) spCarrera.setSelection(0);
        if (spTipoIntercambio != null) spTipoIntercambio.setSelection(0);
        if (spEstadoMaterial != null) spEstadoMaterial.setSelection(0);
        if (spSede != null) spSede.setSelection(0);

        Intent result = new Intent();
        result.putExtra("categoria", "");
        result.putExtra("carrera", "");
        result.putExtra("tipo", "");
        result.putExtra("estado", "");
        result.putExtra("sede", "");
        setResult(RESULT_OK, result);
        finish();
    }
}
