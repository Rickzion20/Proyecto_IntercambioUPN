package com.example.intercambioupn;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class editar_publicacion extends AppCompatActivity {

    private EditText txtNombreMaterial;
    private EditText txtDescripcionMaterial;
    private EditText txtUrlImagen;

    private Spinner spCategoriaMaterial;
    private Spinner spTipoIntercambio;
    private Spinner spEstadoMaterial;
    private Spinner spSedeMaterial;

    private String id = "";
    private String nombre = "";
    private String descripcion = "";
    private String foto = "";
    private String categoria = "";
    private String tipo = "";
    private String estado = "";
    private String sede = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editar_publicacion);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNombreMaterial = findViewById(R.id.txtNombreMaterial);
        txtDescripcionMaterial = findViewById(R.id.txtDescripcionMaterial);
        txtUrlImagen = findViewById(R.id.txtUrlImagen);

        spCategoriaMaterial = findViewById(R.id.spCategoriaMaterial);
        spTipoIntercambio = findViewById(R.id.spTipoIntercambio);
        spEstadoMaterial = findViewById(R.id.spEstadoMaterial);
        spSedeMaterial = findViewById(R.id.spSedeMaterial);

        Intent intent = getIntent();
        if (intent != null) {
            id = intent.getStringExtra("id") != null ? intent.getStringExtra("id") : "";
            nombre = intent.getStringExtra("nombre") != null ? intent.getStringExtra("nombre") : "";
            descripcion = intent.getStringExtra("descripcion") != null ? intent.getStringExtra("descripcion") : "";
            foto = intent.getStringExtra("foto") != null ? intent.getStringExtra("foto") : "";
            categoria = intent.getStringExtra("categoria") != null ? intent.getStringExtra("categoria") : "";
            tipo = intent.getStringExtra("tipo") != null ? intent.getStringExtra("tipo") : "";
            estado = intent.getStringExtra("estado") != null ? intent.getStringExtra("estado") : "";
            sede = intent.getStringExtra("sede") != null ? intent.getStringExtra("sede") : "";

            txtNombreMaterial.setText(nombre);
            txtDescripcionMaterial.setText(descripcion);
            txtUrlImagen.setText(foto);

            setSpinnerSelection(spCategoriaMaterial, categoria);
            setSpinnerSelection(spTipoIntercambio, tipo);
            setSpinnerSelection(spEstadoMaterial, estado);
            setSpinnerSelection(spSedeMaterial, sede);
        }
    }

    private void setSpinnerSelection(Spinner spinner, String value) {
        if (spinner == null || value == null || value.isEmpty()) return;
        ArrayAdapter adapter = (ArrayAdapter) spinner.getAdapter();
        if (adapter != null) {
            for (int i = 0; i < adapter.getCount(); i++) {
                if (adapter.getItem(i).toString().equalsIgnoreCase(value)) {
                    spinner.setSelection(i);
                    break;
                }
            }
        }
    }

    public void regresar(View view) {
        finish();
    }

    public void irEliminarPublicacion(View view) {
        Intent intent = new Intent(editar_publicacion.this, eliminar_publicacion.class);
        intent.putExtra("id", id);
        intent.putExtra("nombre", txtNombreMaterial.getText().toString());
        startActivity(intent);
        finish();
    }

    public void actualizarPublicacion(View view) {
        Update();
    }

    public void Update() {
        String p_nombre = txtNombreMaterial.getText().toString().trim();
        String p_descripcion = txtDescripcionMaterial.getText().toString().trim();
        String p_imagen_url = txtUrlImagen.getText().toString().trim();

        String p_categoria = spCategoriaMaterial.getSelectedItem() != null ? spCategoriaMaterial.getSelectedItem().toString() : "";
        String p_tipo = spTipoIntercambio.getSelectedItem() != null ? spTipoIntercambio.getSelectedItem().toString() : "";
        String p_estado = spEstadoMaterial.getSelectedItem() != null ? spEstadoMaterial.getSelectedItem().toString() : "";
        String p_sede = spSedeMaterial != null && spSedeMaterial.getSelectedItem() != null ? spSedeMaterial.getSelectedItem().toString() : "";

        if (p_nombre.isEmpty()) {
            Toast.makeText(this, "Ingrese nombre", Toast.LENGTH_SHORT).show();
        } else if (p_descripcion.isEmpty()) {
            Toast.makeText(this, "Ingrese descripción", Toast.LENGTH_SHORT).show();
        } else if (p_imagen_url.isEmpty()) {
            Toast.makeText(this, "Ingrese url de imagen", Toast.LENGTH_SHORT).show();
        } else {
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setMessage("Actualizando...");
            progressDialog.show();

            StringRequest request = new StringRequest(
                    Request.Method.POST,
                    "http://192.168.1.38:80/crud_intercambio/actualizar_.php",
                    new Response.Listener<String>() {
                        @Override
                        public void onResponse(String response) {
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            Toast.makeText(editar_publicacion.this, "Actualizó correctamente", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                            startActivity(intent);
                            finish();
                        }
                    },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            if (progressDialog.isShowing()) {
                                progressDialog.dismiss();
                            }
                            Toast.makeText(editar_publicacion.this, "Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
            ) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String, String> params = new HashMap<>();
                    params.put("id", id);
                    params.put("nombre_material", p_nombre);
                    params.put("nombre", p_nombre);
                    params.put("descripcion", p_descripcion);
                    params.put("foto", p_imagen_url);
                    params.put("categoria", p_categoria);
                    params.put("tipo", p_tipo);
                    params.put("estado", p_estado);
                    params.put("sede", p_sede);
                    return params;
                }
            };

            RequestQueue requestQueue = Volley.newRequestQueue(editar_publicacion.this);
            requestQueue.add(request);
        }
    }
}
