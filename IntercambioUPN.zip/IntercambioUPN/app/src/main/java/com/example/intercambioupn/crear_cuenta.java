package com.example.intercambioupn;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class crear_cuenta extends AppCompatActivity {
    private EditText txtNombres;
    private EditText txtApellidos;
    private EditText txtCorreo;
    private EditText txtCarrera;
    private EditText txtContrasena;
    private EditText txtConfirmarContrasena;
    private Button btnRegistrarCuenta;

    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_crear_cuenta);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference("Usuarios");

        txtNombres = findViewById(R.id.txtNombres);
        txtApellidos = findViewById(R.id.txtApellidos);
        txtCorreo = findViewById(R.id.txtCorreo);
        txtCarrera = findViewById(R.id.txtCarrera);
        txtContrasena = findViewById(R.id.txtContrasena);
        txtConfirmarContrasena = findViewById(R.id.txtConfirmarContrasena);
        btnRegistrarCuenta = findViewById(R.id.btnRegistrarCuenta);
    }

    public void regresar(View view) {
        Intent intent = new Intent(crear_cuenta.this, login.class);
        startActivity(intent);
        finish();
    }

    public void crearcuenta(View view) {
        String nombres = txtNombres.getText().toString().trim();
        String apellidos = txtApellidos.getText().toString().trim();
        String correo = txtCorreo.getText().toString().trim();
        String carrera = txtCarrera.getText().toString().trim();
        String contrasena = txtContrasena.getText().toString().trim();
        String confirmarContrasena = txtConfirmarContrasena.getText().toString().trim();

        if (TextUtils.isEmpty(nombres) || TextUtils.isEmpty(apellidos) ||
                TextUtils.isEmpty(correo) || TextUtils.isEmpty(carrera) ||
                TextUtils.isEmpty(contrasena) || TextUtils.isEmpty(confirmarContrasena)) {
            Toast.makeText(this, "Por favor, completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!contrasena.equals(confirmarContrasena)) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show();
            return;
        }

        if (contrasena.length() < 6) {
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show();
            return;
        }

        // Crear la cuenta en Firebase Authentication
        mAuth.createUserWithEmailAndPassword(correo, contrasena)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser user = mAuth.getCurrentUser();
                        if (user != null) {
                            // Actualizar el nombre completo en el perfil de Firebase Authentication
                            UserProfileChangeRequest profileUpdates = new UserProfileChangeRequest.Builder()
                                    .setDisplayName(nombres + " " + apellidos)
                                    .build();
                            user.updateProfile(profileUpdates);

                            String uid = user.getUid();

                            // Guardar datos adicionales en Firebase Realtime Database
                            Map<String, Object> usuarioMap = new HashMap<>();
                            usuarioMap.put("uid", uid);
                            usuarioMap.put("nombres", nombres);
                            usuarioMap.put("apellidos", apellidos);
                            usuarioMap.put("correo", correo);
                            usuarioMap.put("carrera", carrera);

                            mDatabase.child(uid).setValue(usuarioMap)
                                    .addOnCompleteListener(dbTask -> {
                                        if (dbTask.isSuccessful()) {
                                            // Cerrar sesión activa para que el usuario pueda iniciar sesión manualmente en Login
                                            mAuth.signOut();
                                            Toast.makeText(crear_cuenta.this, "Cuenta creada exitosamente en Authentication y Base de Datos", Toast.LENGTH_SHORT).show();
                                            Intent intent = new Intent(crear_cuenta.this, cuenta_creada.class);
                                            startActivity(intent);
                                            finish();
                                        } else {
                                            Toast.makeText(crear_cuenta.this, "Error al guardar en la base de datos", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }
                    } else {
                        Toast.makeText(crear_cuenta.this, "Error al registrar en Authentication: " + (task.getException() != null ? task.getException().getMessage() : ""), Toast.LENGTH_SHORT).show();
                    }
                });
    }
}
