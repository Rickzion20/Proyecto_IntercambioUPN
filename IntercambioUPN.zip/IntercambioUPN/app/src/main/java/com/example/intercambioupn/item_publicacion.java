package com.example.intercambioupn;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageRequest;
import com.android.volley.toolbox.Volley;

public class item_publicacion extends AppCompatActivity {

    private ImageView imgMaterial;
    private TextView txtNombreMaterial;
    private TextView txtCategoria;
    private TextView txtTipo;
    private TextView txtEstado;
    private TextView txtCarrera;
    private TextView txtSede;
    private TextView txtDescripcion;

    private RequestQueue rq;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_item_publicacion);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        rq = Volley.newRequestQueue(this);

        imgMaterial = findViewById(R.id.imgMaterial);
        txtNombreMaterial = findViewById(R.id.txtNombreMaterial);
        txtCategoria = findViewById(R.id.txtCategoria);
        txtTipo = findViewById(R.id.txtTipo);
        txtEstado = findViewById(R.id.txtEstado);
        txtCarrera = findViewById(R.id.txtCarrera);
        txtSede = findViewById(R.id.txtSede);
        txtDescripcion = findViewById(R.id.txtDescripcion);

        cargarDetalles();
    }

    private void cargarDetalles() {
        Intent intent = getIntent();
        if (intent != null) {
            String nombre = intent.getStringExtra("nombre");
            String descripcion = intent.getStringExtra("descripcion");
            String categoria = intent.getStringExtra("categoria");
            String tipo = intent.getStringExtra("tipo");
            String estado = intent.getStringExtra("estado");
            String sede = intent.getStringExtra("sede");
            String carrera = intent.getStringExtra("carrera");
            String foto = intent.getStringExtra("foto");

            if (txtNombreMaterial != null && nombre != null) txtNombreMaterial.setText(nombre);
            if (txtDescripcion != null && descripcion != null) txtDescripcion.setText(descripcion);
            if (txtCategoria != null && categoria != null) txtCategoria.setText(categoria);
            if (txtTipo != null && tipo != null) txtTipo.setText("Tipo: " + tipo);
            if (txtEstado != null && estado != null) txtEstado.setText(estado);
            if (txtSede != null && sede != null) txtSede.setText(sede);
            if (txtCarrera != null) {
                if (carrera != null && !carrera.isEmpty()) {
                    txtCarrera.setText(carrera);
                } else {
                    txtCarrera.setText("Todas las carreras");
                }
            }

            if (imgMaterial != null && foto != null && !foto.isEmpty()) {
                cargarImagen(foto);
            }
        }
    }

    private void cargarImagen(String url) {
        ImageRequest peticion = new ImageRequest(
                url,
                new Response.Listener<Bitmap>() {
                    @Override
                    public void onResponse(Bitmap response) {
                        if (imgMaterial != null) {
                            imgMaterial.setImageBitmap(response);
                        }
                    }
                },
                0,
                0,
                ImageView.ScaleType.CENTER_CROP,
                Bitmap.Config.RGB_565,
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        if (imgMaterial != null) {
                            imgMaterial.setImageResource(R.drawable.ic_launcher_foreground);
                        }
                    }
                }
        );
        rq.add(peticion);
    }

    public void regresar(View view) {
        finish();
    }

    public void contactarEstudiante(View view) {
        Toast.makeText(this, "¡Solicitud de intercambio enviada!", Toast.LENGTH_LONG).show();
    }
}
