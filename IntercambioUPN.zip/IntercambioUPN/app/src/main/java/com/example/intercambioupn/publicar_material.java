package com.example.intercambioupn;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class publicar_material extends AppCompatActivity {

    private EditText txtNombreMaterial;
    private EditText txtDescripcionMaterial;

    private Spinner spCategoriaMaterial;
    private Spinner spTipoPublicacion;
    private Spinner spEstadoPublicacion;
    private Spinner spSedeMaterial;
    private EditText txtUrlImagen;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_publicar_material);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNombreMaterial = findViewById(R.id.txtNombreMaterial);
        txtDescripcionMaterial = findViewById(R.id.txtDescripcionMaterial);
        spCategoriaMaterial = findViewById(R.id.spCategoriaMaterial);
        spTipoPublicacion = findViewById(R.id.spTipoPublicacion);
        spEstadoPublicacion = findViewById(R.id.spEstadoPublicacion);
        spSedeMaterial = findViewById(R.id.spSedeMaterial);
        txtUrlImagen = findViewById(R.id.txtUrlImagen);
    }

    public void regresar(View view) {
        finish();
    }

    public void publicar_material(View view) {
        insert();
    }

    public void insert() {
        try {
            String p_nombre = txtNombreMaterial != null && txtNombreMaterial.getText() != null ? txtNombreMaterial.getText().toString().trim() : "";
            String p_descripcion = txtDescripcionMaterial != null && txtDescripcionMaterial.getText() != null ? txtDescripcionMaterial.getText().toString().trim() : "";
            String p_categoria = spCategoriaMaterial != null && spCategoriaMaterial.getSelectedItem() != null ? spCategoriaMaterial.getSelectedItem().toString() : "";
            String p_tipo = spTipoPublicacion != null && spTipoPublicacion.getSelectedItem() != null ? spTipoPublicacion.getSelectedItem().toString() : "";
            String p_estado = spEstadoPublicacion != null && spEstadoPublicacion.getSelectedItem() != null ? spEstadoPublicacion.getSelectedItem().toString() : "";
            String p_sede = spSedeMaterial != null && spSedeMaterial.getSelectedItem() != null ? spSedeMaterial.getSelectedItem().toString() : "";
            String p_foto = txtUrlImagen != null && txtUrlImagen.getText() != null ? txtUrlImagen.getText().toString().trim() : "";

            if (p_nombre.isEmpty()) {
                Toast.makeText(this, "Ingrese nombre del material", Toast.LENGTH_SHORT).show();
            } else if (p_descripcion.isEmpty()) {
                Toast.makeText(this, "Ingrese descripción", Toast.LENGTH_SHORT).show();
            } else if (spCategoriaMaterial != null && spCategoriaMaterial.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione una categoría", Toast.LENGTH_SHORT).show();
            } else if (spTipoPublicacion != null && spTipoPublicacion.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione un tipo de intercambio", Toast.LENGTH_SHORT).show();
            } else if (spEstadoPublicacion != null && spEstadoPublicacion.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione un estado", Toast.LENGTH_SHORT).show();
            } else if (spSedeMaterial != null && spSedeMaterial.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione una sede", Toast.LENGTH_SHORT).show();
            } else if (p_foto.isEmpty()) {
                Toast.makeText(this, "Ingrese URL de la imagen", Toast.LENGTH_SHORT).show();
            } else {
                ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Publicando material...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                StringRequest request = new StringRequest(
                        Request.Method.POST,
                        "http://192.168.1.38:80/crud_intercambio/insertar_.php",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }

                                Toast.makeText(
                                        publicar_material.this,
                                        response != null ? response.trim() : "Material publicado exitosamente",
                                        Toast.LENGTH_SHORT
                                ).show();

                                Intent intent = new Intent(publicar_material.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if (progressDialog != null && progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }

                                String msg = error != null && error.getMessage() != null ? error.getMessage() : "Error de red o servidor";
                                Toast.makeText(
                                        publicar_material.this,
                                        "Error al publicar: " + msg,
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("nombre_material", p_nombre);
                        params.put("nombre", p_nombre);
                        params.put("descripcion", p_descripcion);
                        params.put("categoria", p_categoria);
                        params.put("tipo", p_tipo);
                        params.put("estado", p_estado);
                        params.put("sede", p_sede);
                        params.put("foto", p_foto);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(publicar_material.this);
                requestQueue.add(request);
            }
        } catch (Exception ex) {
            Toast.makeText(
                    this,
                    "Error al procesar los datos: " + ex.getMessage(),
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
