package com.example.intercambioupn;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class publicar_material extends AppCompatActivity {

    private EditText txtNombreMaterial;
    private EditText txtDescripcionMaterial;
    private EditText txtUrlImagen;

    private Spinner spCategoriaMaterial;
    private Spinner spTipoPublicacion;
    private Spinner spEstadoPublicacion;
    private Spinner spSedeMaterial;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_publicar_material);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNombreMaterial = findViewById(R.id.txtNombreMaterial);
        txtDescripcionMaterial = findViewById(R.id.txtDescripcionMaterial);
        txtUrlImagen = findViewById(R.id.txtUrlImagen);

        spCategoriaMaterial = findViewById(R.id.spCategoriaMaterial);
        spTipoPublicacion = findViewById(R.id.spTipoPublicacion);
        spEstadoPublicacion = findViewById(R.id.spEstadoPublicacion);
        spSedeMaterial = findViewById(R.id.spSedeMaterial);
    }

    public void regresar(View view) {
        finish();
    }

    public void publicar_material(View view) {
        insert();
    }

    public void insert() {
        try {
            String p_nombre = txtNombreMaterial.getText().toString().trim();
            String p_descripcion = txtDescripcionMaterial.getText().toString().trim();
            String p_foto = txtUrlImagen.getText().toString().trim();

            String p_categoria = spCategoriaMaterial.getSelectedItem() != null ? spCategoriaMaterial.getSelectedItem().toString() : "";
            String p_tipo = spTipoPublicacion.getSelectedItem() != null ? spTipoPublicacion.getSelectedItem().toString() : "";
            String p_estado = spEstadoPublicacion.getSelectedItem() != null ? spEstadoPublicacion.getSelectedItem().toString() : "";
            String p_sede = spSedeMaterial != null && spSedeMaterial.getSelectedItem() != null ? spSedeMaterial.getSelectedItem().toString() : "";

            if (p_nombre.isEmpty()) {
                Toast.makeText(this, "Ingrese nombre del material", Toast.LENGTH_SHORT).show();
            } else if (p_descripcion.isEmpty()) {
                Toast.makeText(this, "Ingrese descripción", Toast.LENGTH_SHORT).show();
            } else if (p_foto.isEmpty()) {
                Toast.makeText(this, "Ingrese URL de la imagen", Toast.LENGTH_SHORT).show();
            } else if (spCategoriaMaterial.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione una categoría", Toast.LENGTH_SHORT).show();
            } else if (spTipoPublicacion.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione un tipo de intercambio", Toast.LENGTH_SHORT).show();
            } else if (spEstadoPublicacion.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione un estado", Toast.LENGTH_SHORT).show();
            } else if (spSedeMaterial != null && spSedeMaterial.getSelectedItemPosition() == 0) {
                Toast.makeText(this, "Seleccione una sede", Toast.LENGTH_SHORT).show();
            } else {
                ProgressDialog progressDialog = new ProgressDialog(this);
                progressDialog.setMessage("Publicando material...");
                progressDialog.setCancelable(false);
                progressDialog.show();

                StringRequest request = new StringRequest(
                        Request.Method.POST,
                        "http://192.168.1.35:80/crud_intercambio/insertar_.php",
                        new Response.Listener<String>() {
                            @Override
                            public void onResponse(String response) {
                                if (progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }

                                Toast.makeText(
                                        publicar_material.this,
                                        response != null ? response.trim() : "Material publicado exitosamente",
                                        Toast.LENGTH_SHORT
                                ).show();

                                Intent intent = new Intent(publicar_material.this, MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        },
                        new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {
                                if (progressDialog.isShowing()) {
                                    progressDialog.dismiss();
                                }

                                Toast.makeText(
                                        publicar_material.this,
                                        "Error al publicar: " + error.toString(),
                                        Toast.LENGTH_LONG
                                ).show();
                            }
                        }
                ) {
                    @Override
                    protected Map<String, String> getParams() throws AuthFailureError {
                        Map<String, String> params = new HashMap<>();
                        params.put("nombre_material", p_nombre);
                        params.put("nombre", p_nombre);
                        params.put("descripcion", p_descripcion);
                        params.put("categoria", p_categoria);
                        params.put("tipo", p_tipo);
                        params.put("estado", p_estado);
                        params.put("sede", p_sede);
                        params.put("foto", p_foto);
                        return params;
                    }
                };

                RequestQueue requestQueue = Volley.newRequestQueue(publicar_material.this);
                requestQueue.add(request);
            }
        } catch (Exception ex) {
            Toast.makeText(
                    this,
                    "Verificar los datos ingresados",
                    Toast.LENGTH_SHORT
            ).show();
        }
    }
}
