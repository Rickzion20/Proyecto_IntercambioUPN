package com.example.intercambioupn;

public class Material {

    private String id;
    private String nombre;
    private String descripcion;
    private String categoria;
    private String tipo;
    private String estado;
    private String sede;
    private String carrera;
    private String foto;

    public Material(
            String id,
            String nombre,
            String descripcion,
            String categoria,
            String tipo,
            String estado,
            String sede,
            String foto) {
        this(id, nombre, descripcion, categoria, tipo, estado, sede, "", foto);
    }

    public Material(
            String id,
            String nombre,
            String descripcion,
            String categoria,
            String tipo,
            String estado,
            String sede,
            String carrera,
            String foto) {

        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.categoria = categoria;
        this.tipo = tipo;
        this.estado = estado;
        this.sede = sede;
        this.carrera = carrera;
        this.foto = foto;
    }

    public String getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public String getCategoria() {
        return categoria;
    }

    public String getTipo() {
        return tipo;
    }

    public String getEstado() {
        return estado;
    }

    public String getSede() {
        return sede;
    }

    public String getCarrera() {
        return carrera;
    }

    public String getFoto() {
        return foto;
    }
}
