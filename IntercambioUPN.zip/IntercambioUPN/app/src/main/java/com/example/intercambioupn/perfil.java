package com.example.intercambioupn;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class perfil extends AppCompatActivity {

    private TextView txtNombreCompleto;
    private TextView txtCorreoPerfil;
    private TextView txtNombrePerfil;
    private TextView txtCarreraPerfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_perfil);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        txtNombreCompleto = findViewById(R.id.txtNombreCompleto);
        txtCorreoPerfil = findViewById(R.id.txtCorreoPerfil);
        txtNombrePerfil = findViewById(R.id.txtNombrePerfil);
        txtCarreraPerfil = findViewById(R.id.txtCarreraPerfil);

        cargarDatosUsuario();
    }

    private void cargarDatosUsuario() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            if (currentUser.getDisplayName() != null && !currentUser.getDisplayName().isEmpty()) {
                txtNombreCompleto.setText(currentUser.getDisplayName());
                txtNombrePerfil.setText(currentUser.getDisplayName());
            }
            if (currentUser.getEmail() != null) {
                txtCorreoPerfil.setText(currentUser.getEmail());
            }

            DatabaseReference mDatabase = FirebaseDatabase.getInstance().getReference("Usuarios").child(currentUser.getUid());
            mDatabase.get().addOnSuccessListener(dataSnapshot -> {
                if (dataSnapshot.exists()) {
                    String nombres = dataSnapshot.child("nombres").getValue(String.class);
                    String apellidos = dataSnapshot.child("apellidos").getValue(String.class);
                    String carrera = dataSnapshot.child("carrera").getValue(String.class);

                    if (nombres != null && apellidos != null) {
                        String nombreCompleto = nombres + " " + apellidos;
                        txtNombreCompleto.setText(nombreCompleto);
                        txtNombrePerfil.setText(nombreCompleto);
                    }
                    if (carrera != null) {
                        txtCarreraPerfil.setText(carrera);
                    }
                }
            });
        }
    }

    public void regresar(View view) {
        finish();
    }

    public void cerrarsesion(View view) {
        Intent intent = new Intent(this, cerrar_sesion.class);
        startActivity(intent);
    }
}
