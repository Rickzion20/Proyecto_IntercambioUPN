package com.example.proyectoupn;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.content.Intent;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;


public class login extends AppCompatActivity {
    EditText etCorreo, etClave;
    RadioGroup rgCuenta;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        etCorreo = findViewById(R.id.etEmail);
        etClave = findViewById(R.id.etPassword);
        rgCuenta = findViewById(R.id.rgAccount);

        findViewById(R.id.btnLogin).setOnClickListener(v -> {
            String correo = etCorreo.getText().toString().trim();
            String clave = etClave.getText().toString();

            if (correo.isEmpty() || clave.isEmpty()) {
                mostrarMensaje("Completa el correo y la contraseña.");
                return;
            }

            String tipo = rgCuenta.getCheckedRadioButtonId()
                    == R.id.rbStudent ? "Estudiante" : "Externa";

            getSharedPreferences("sesion", MODE_PRIVATE)
                    .edit()
                    .putString("correo", correo)
                    .putString("cuenta", tipo)
                    .apply();

            startActivity(new Intent(this, MainActivity.class));
            finish();
        });

        findViewById(R.id.btnRegister).setOnClickListener(v ->
                startActivity(new Intent(this, registrar.class)));

        findViewById(R.id.btnForgot).setOnClickListener(v ->
                startActivity(new Intent(this, olvidarcontra.class)));
    }

    private void mostrarMensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }
}
