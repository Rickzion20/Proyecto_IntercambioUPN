package com.example.proyectoupn;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.util.Patterns;
import android.widget.EditText;
import android.widget.Toast;


public class olvidarcontra extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_olvidarcontra);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        
        findViewById(R.id.btnRecover).setOnClickListener(v -> {
            String correo = ((EditText) findViewById(R.id.etEmail))
                    .getText().toString().trim();

            if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                mostrarMensaje("Ingresa un correo válido.");
                return;
            }

            mostrarMensaje("Conecta Firebase o un servidor para enviar el enlace de recuperación.");
        });

        findViewById(R.id.btnBack).setOnClickListener(v -> finish());
    }

    private void mostrarMensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
