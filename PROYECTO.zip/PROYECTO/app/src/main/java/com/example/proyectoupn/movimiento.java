package com.example.proyectoupn;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class movimiento extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_movimiento);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, barrasDeSistema) -> {
            Insets recortes = barrasDeSistema.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(recortes.left, recortes.top, recortes.right, recortes.bottom);
            return barrasDeSistema;
        });
    }
}