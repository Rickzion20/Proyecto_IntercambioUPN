package com.example.proyectoupn;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.os.Handler;

import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;
public class Splash extends AppCompatActivity {
    private final Handler temporizador = new Handler();

    private TextView tvUniversidad;
    private TextView tvTitulo;
    private TextView tvEslogan;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        tvUniversidad = findViewById(R.id.tvUniversidad);
        tvTitulo = findViewById(R.id.tvTitulo);
        tvEslogan = findViewById(R.id.tvEslogan);

        // Animar los textos uno después del otro.
        temporizador.postDelayed(
                () -> animarTexto(tvUniversidad), 200
        );

        temporizador.postDelayed(
                () -> animarTexto(tvTitulo), 600
        );

        temporizador.postDelayed(
                () -> animarTexto(tvEslogan), 1000
        );

        // Abrir la pantalla de inicio de sesión.
        temporizador.postDelayed(() -> {
            Intent intencion = new Intent(
                    Splash.this,
                    login.class
            );

            startActivity(intencion);
            finish();

        }, 3500);
    }

    private void animarTexto(TextView texto) {
        Animation animacion = AnimationUtils.loadAnimation(
                this,
                R.anim.activity_movimiento
        );

        texto.startAnimation(animacion);
    }

    @Override
    protected void onDestroy() {
        temporizador.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
