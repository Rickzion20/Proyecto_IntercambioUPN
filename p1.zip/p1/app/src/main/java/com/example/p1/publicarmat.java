package com.example.p1;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class publicarmat extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_publicarmat);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        findViewById(R.id.btnSaveMaterial).setOnClickListener(v -> {

            String titulo = texto(R.id.etTitle);
            String categoria = texto(R.id.etCategory);
            String estado = texto(R.id.etCondition);
            String descripcion = texto(R.id.etDescription);
            String intercambio = texto(R.id.etExchange);

            if (titulo.isEmpty() || categoria.isEmpty()
                    || estado.isEmpty() || descripcion.isEmpty()) {

                mensaje("Completa los campos obligatorios.");
                return;
            }

            String propietario = getSharedPreferences(
                    "session", MODE_PRIVATE)
                    .getString("email", "");

            if (propietario.isEmpty()) {
                mensaje("Debes iniciar sesión para publicar.");
                return;
            }

            Material nuevo = new Material(
                    MaterialStore.nextId++,
                    titulo,
                    categoria,
                    estado,
                    descripcion,
                    intercambio,
                    propietario
            );

            MaterialStore.items.add(0, nuevo);

            mensaje("Material publicado correctamente.");
            finish();
        });

        findViewById(R.id.btnCancel).setOnClickListener(v ->
                finish());
    }

    private String texto(int id) {
        return ((EditText) findViewById(id))
                .getText().toString().trim();
    }

    private void mensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }
}
