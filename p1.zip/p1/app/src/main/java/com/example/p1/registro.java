package com.example.p1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import org.json.JSONObject;

public class registro extends AppCompatActivity {

    private EditText editarNombre, editarApellido;
    private EditText editarCorreo, editarCodigo;
    private EditText editarContrasena, editarConfirmar;
    private RadioGroup grupoTipo;
    private RadioButton radioUPN, radioExterna;
    private Button botonRegistrar, botonVolver;

    private FirebaseAuth autenticacion;
    private ApiUsuarios apiUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registro);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        autenticacion = FirebaseAuth.getInstance();
        apiUsuarios = new ApiUsuarios(this);

        editarNombre = findViewById(R.id.editarNombre);
        editarApellido = findViewById(R.id.editarApellido);
        editarCorreo = findViewById(R.id.editarCorreoRegistro);
        editarCodigo = findViewById(R.id.editarCodigo);
        editarContrasena =
                findViewById(R.id.editarContrasenaRegistro);
        editarConfirmar =
                findViewById(R.id.editarConfirmarContrasena);

        grupoTipo = findViewById(R.id.grupoTipoCuenta);
        radioUPN = findViewById(R.id.radioUPN);
        radioExterna = findViewById(R.id.radioExterna);

        botonRegistrar = findViewById(R.id.botonRegistrar);
        botonVolver = findViewById(R.id.botonVolver);

        radioExterna.setOnClickListener(v ->
                editarCodigo.setEnabled(false));

        radioUPN.setOnClickListener(v ->
                editarCodigo.setEnabled(true));

        botonRegistrar.setOnClickListener(v -> crearCuenta());

        botonVolver.setOnClickListener(v -> finish());
    }

    private void crearCuenta() {
        String nombre = editarNombre.getText().toString().trim();
        String apellido = editarApellido.getText().toString().trim();
        String correo = editarCorreo.getText().toString()
                .trim().toLowerCase();
        String codigo = editarCodigo.getText().toString().trim();
        String contrasena = editarContrasena.getText().toString();
        String confirmar = editarConfirmar.getText().toString();

        String tipo = radioUPN.isChecked() ? "UPN" : "EXTERNA";

        if (TextUtils.isEmpty(nombre)
                || TextUtils.isEmpty(apellido)
                || TextUtils.isEmpty(correo)
                || TextUtils.isEmpty(contrasena)
                || TextUtils.isEmpty(confirmar)) {
            mensaje("Completa los campos obligatorios");
            return;
        }

        if (tipo.equals("UPN") && TextUtils.isEmpty(codigo)) {
            mensaje("Ingresa tu código de estudiante");
            return;
        }

        if (contrasena.length() < 6) {
            mensaje("La contraseña debe tener al menos 6 caracteres");
            return;
        }

        if (!contrasena.equals(confirmar)) {
            mensaje("Las contraseñas no coinciden");
            return;
        }

        botonRegistrar.setEnabled(false);

        autenticacion.createUserWithEmailAndPassword(
                correo, contrasena
        ).addOnCompleteListener(this, tarea -> {
            if (!tarea.isSuccessful()) {
                botonRegistrar.setEnabled(true);
                mensaje("No se pudo crear la cuenta: "
                        + tarea.getException().getMessage());
                return;
            }

            FirebaseUser usuario =
                    autenticacion.getCurrentUser();

            if (usuario == null) {
                botonRegistrar.setEnabled(true);
                mensaje("No se pudo obtener el usuario");
                return;
            }

            String codigoFinal =
                    tipo.equals("UPN") ? codigo : "";

            usuario.getIdToken(true).addOnCompleteListener(tokenTarea -> {
                if (!tokenTarea.isSuccessful()
                        || tokenTarea.getResult() == null) {
                    botonRegistrar.setEnabled(true);
                    mensaje("No se pudo validar la cuenta");
                    return;
                }

                String token =
                        tokenTarea.getResult().getToken();

                apiUsuarios.registrarPerfil(
                        token, nombre, apellido, correo,
                        codigoFinal, tipo,
                        new ApiUsuarios.RespuestaApi() {
                            @Override
                            public void correcto(JSONObject respuesta) {
                                mensaje("Cuenta creada correctamente");
                                startActivity(new Intent(
                                        registro.this, bienvenida.class));
                                finish();
                            }

                            @Override
                            public void error(String mensajeError) {
                                botonRegistrar.setEnabled(true);
                                mensaje("La cuenta de Firebase se creó, "
                                        + "pero no se guardó el perfil en MySQL: "
                                        + mensajeError);
                            }
                        }
                );
            });
        });
    }

    private void mensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
