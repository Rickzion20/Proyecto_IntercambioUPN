package com.example.p1;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class detallemat extends AppCompatActivity {
    public static Material selected;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_detallemat);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        if (selected != null) {
            ((TextView) findViewById(R.id.tvMaterialTitle))
                    .setText(selected.titulo);

            ((TextView) findViewById(R.id.tvMaterialCategory))
                    .setText("Categoría: " + selected.categoria);

            ((TextView) findViewById(R.id.tvMaterialCondition))
                    .setText("Estado: " + selected.condicion);

            ((TextView) findViewById(R.id.tvMaterialDescription))
                    .setText("Descripción: " + selected.descripcion
                            + "\n\nIntercambio deseado: "
                            + selected.intercambio);

            ((TextView) findViewById(R.id.tvMaterialOwner))
                    .setText("Publicado por: " + selected.propietario);
        }

        findViewById(R.id.btnContactOwner).setOnClickListener(v ->
                Toast.makeText(this,
                        "Aquí puedes integrar el chat entre usuarios.",
                        Toast.LENGTH_LONG).show());

        findViewById(R.id.btnDetailBack).setOnClickListener(v ->
                finish());
    }
}
    }
}