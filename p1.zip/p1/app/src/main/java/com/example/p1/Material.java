package com.example.p1;

public class Material {
    public int id;
    public String titulo;
    public String categoria;
    public String condicion;
    public String descripcion;
    public String intercambio;
    public String propietario;
    public boolean eliminado = false;

    public Material(int id, String titulo, String categoria, String condicion, String descripcion, String intercambio, String propietario) {
        this.id = id;
        this.titulo = titulo;
        this.categoria = categoria;
        this.condicion = condicion;
        this.descripcion = descripcion;
        this.intercambio = intercambio;
        this.propietario = propietario;
        this.eliminado = eliminado;
    }
}
