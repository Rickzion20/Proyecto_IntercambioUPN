package com.example.p1;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.util.Patterns;
import android.widget.EditText;
import android.widget.Toast;

public class registrar extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_registrar);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        findViewById(R.id.btnCreateAccount).setOnClickListener(v -> {

            String nombre = obtenerTexto(R.id.etName);
            String correo = obtenerTexto(R.id.etEmail);
            String codigo = obtenerTexto(R.id.etCode);
            String clave = obtenerTexto(R.id.etPassword);
            String confirmarClave = obtenerTexto(R.id.etConfirmPassword);

            if (nombre.isEmpty() || correo.isEmpty()
                    || clave.isEmpty() || confirmarClave.isEmpty()) {
                mostrarMensaje("Completa todos los campos obligatorios.");
                return;
            }

            if (!Patterns.EMAIL_ADDRESS.matcher(correo).matches()) {
                mostrarMensaje("Ingresa un correo válido.");
                return;
            }

            if (clave.length() < 8) {
                mostrarMensaje("La contraseña debe tener al menos 8 caracteres.");
                return;
            }

            if (!clave.equals(confirmarClave)) {
                mostrarMensaje("Las contraseñas no coinciden.");
                return;
            }

            mostrarMensaje("Formulario validado. Falta registrar la cuenta en el servidor.");
        });

        findViewById(R.id.btnBackLogin).setOnClickListener(v -> finish());
    }

    private String obtenerTexto(int id) {
        return ((EditText) findViewById(id))
                .getText().toString().trim();
    }

    private void mostrarMensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
