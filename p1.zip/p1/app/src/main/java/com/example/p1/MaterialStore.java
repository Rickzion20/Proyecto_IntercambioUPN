
package com.example.p1;

import java.util.ArrayList;

public class MaterialStore {

    public static ArrayList<Material> items =
            new ArrayList<>();

    public static int nextId = 1;

    static {
        items.add(new Material(
                nextId++,
                "Libro de Matemática",
                "Libros",
                "Usado",
                "Libro en buen estado, sin páginas faltantes.",
                "Apuntes de programación",
                "demo@ejemplo.com"
        ));

        items.add(new Material(
                nextId++,
                "Resumen de Redes",
                "Apuntes",
                "Bueno",
                "Resumen de las capas OSI y protocolos.",
                "Otro material académico",
                "externo@ejemplo.com"
        ));
    }
}
