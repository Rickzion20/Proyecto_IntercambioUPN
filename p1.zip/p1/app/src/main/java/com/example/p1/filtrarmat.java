package com.example.p1;

import android.annotation.SuppressLint;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

public class filtrarmat extends AppCompatActivity {
    public static class HomeActivityFilter {
        public static String category = "";
    }

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_filtrarmat);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        EditText category = findViewById(R.id.etCategory);
        EditText condition = findViewById(R.id.etCondition);
        EditText course = findViewById(R.id.etCourse);

        category.setText(HomeActivityFilter.category);

        findViewById(R.id.btnApplyFilter).setOnClickListener(v -> {
            HomeActivityFilter.category =
                    category.getText().toString().trim();

            Intent intent = new Intent(this, MainActivity.class);
            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivity(intent);
            finish();
        });

        findViewById(R.id.btnClearFilter).setOnClickListener(v -> {
            category.setText("");
            condition.setText("");
            course.setText("");
            HomeActivityFilter.category = "";
        });

        findViewById(R.id.btnBackHome).setOnClickListener(v ->
                finish());
    }
}
