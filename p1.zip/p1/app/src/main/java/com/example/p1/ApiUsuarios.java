package com.example.p1;
import android.content.Context;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONObject;
public class ApiUsuarios {
    private static final String URL_REGISTRO =
            "http://10.144.86.175/intercambio/registrar_usuario.php";

    private final RequestQueue cola;

    public ApiUsuarios(Context contexto) {
        cola = Volley.newRequestQueue(
                contexto.getApplicationContext()
        );
    }

    public void registrarPerfil(
            String token,
            String nombre,
            String apellido,
            String correo,
            String codigo,
            String tipoCuenta,
            RespuestaApi respuesta
    ) {
        try {
            JSONObject datos = new JSONObject();
            datos.put("nombre", nombre);
            datos.put("apellido", apellido);
            datos.put("correo", correo);
            datos.put("codigo_estudiante", codigo);
            datos.put("tipo_cuenta", tipoCuenta);

            JsonObjectRequest peticion = new JsonObjectRequest(
                    Request.Method.POST,
                    URL_REGISTRO,
                    datos,
                    respuesta::correcto,
                    error -> respuesta.error(
                            error.getMessage() == null
                                    ? "No se pudo conectar con el servidor"
                                    : error.getMessage()
                    )
            ) {
                @Override
                public java.util.Map<String, String>
                getHeaders() {
                    java.util.Map<String, String> cabeceras =
                            new java.util.HashMap<>();
                    cabeceras.put(
                            "Authorization",
                            "Bearer " + token
                    );
                    return cabeceras;
                }
            };

            cola.add(peticion);

        } catch (Exception e) {
            respuesta.error("Error al preparar los datos");
        }
    }

    public interface RespuestaApi {
        void correcto(JSONObject respuesta);
        void error(String mensaje);
    }
}
