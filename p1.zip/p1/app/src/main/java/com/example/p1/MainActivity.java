package com.example.p1;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private LinearLayout llLista;
    private EditText etBusqueda;

    // Simulación de almacén de datos global
    public static List<Material> listaMaterialesGlobal = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (vista, insets) -> {
            Insets barrasSistema = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            vista.setPadding(barrasSistema.left, barrasSistema.top, barrasSistema.right, barrasSistema.bottom);
            return insets;
        });

        llLista = findViewById(R.id.listMaterials);
        etBusqueda = findViewById(R.id.etSearch);

        findViewById(R.id.btnPublish).setOnClickListener(v -> {
            mostrarMensaje("Funcionalidad de publicar próximamente.");
        });

        findViewById(R.id.btnMyPublications).setOnClickListener(v -> {
            mostrarMensaje("Mis publicaciones próximamente.");
        });

        findViewById(R.id.btnFilter).setOnClickListener(v -> {
            mostrarMensaje("Filtros próximamente.");
        });

        findViewById(R.id.btnSearch).setOnClickListener(v -> {
            String consulta = etBusqueda.getText().toString();
            actualizarLista(consulta, "");
        });

        findViewById(R.id.btnLogout).setOnClickListener(v -> {
            getSharedPreferences("sesion", MODE_PRIVATE)
                    .edit().clear().apply();

            Intent intencion = new Intent(this, login.class);
            intencion.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intencion);
            finish();
        });

        actualizarLista("", "");
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (llLista != null) {
            actualizarLista(etBusqueda.getText().toString(), "");
        }
    }

    private void actualizarLista(String consulta, String categoriaFiltro) {
        llLista.removeAllViews();
        boolean encontrado = false;

        for (Material item : listaMaterialesGlobal) {
            if (item.eliminado) continue;

            String busqueda = consulta.toLowerCase().trim();

            boolean coincideBusqueda = item.titulo.toLowerCase().contains(busqueda)
                    || item.categoria.toLowerCase().contains(busqueda)
                    || item.descripcion.toLowerCase().contains(busqueda);

            boolean coincideCategoria = categoriaFiltro == null
                    || categoriaFiltro.trim().isEmpty()
                    || item.categoria.toLowerCase().contains(categoriaFiltro.toLowerCase().trim());

            if (!coincideBusqueda || !coincideCategoria) continue;

            encontrado = true;

            Button tarjeta = new Button(this);
            tarjeta.setAllCaps(false);
            tarjeta.setText(item.titulo + "\n" + item.categoria + " · " + item.condicion);
            llLista.addView(tarjeta);

            tarjeta.setOnClickListener(v -> {
                mostrarMensaje("Detalle de: " + item.titulo);
            });
        }

        if (!encontrado) {
            TextView tvVacio = new TextView(this);
            tvVacio.setText("No se encontraron materiales.");
            tvVacio.setPadding(8, 24, 8, 24);
            llLista.addView(tvVacio);
        }
    }

    private void mostrarMensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }
}
