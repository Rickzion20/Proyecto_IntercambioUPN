package com.example.p1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;



import com.google.firebase.auth.FirebaseAuth;


public class MainActivity extends AppCompatActivity {
    private EditText editarCorreo, editarContrasena;
    private Button botonIngresar, botonCrearCuenta;
    private TextView textoRecuperar;
    private FirebaseAuth autenticacion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        autenticacion = FirebaseAuth.getInstance();

        editarCorreo = findViewById(R.id.editarCorreo);
        editarContrasena = findViewById(R.id.editarContrasena);
        botonIngresar = findViewById(R.id.botonIngresar);
        botonCrearCuenta = findViewById(R.id.botonCrearCuenta);
        textoRecuperar = findViewById(R.id.textoRecuperar);

        botonIngresar.setOnClickListener(v -> iniciarSesion());

        botonCrearCuenta.setOnClickListener(v ->
                startActivity(new Intent(
                        this, registro.class)));

        textoRecuperar.setOnClickListener(v ->
                recuperarContrasena());
    }

    private void iniciarSesion() {
        String correo = editarCorreo.getText().toString()
                .trim().toLowerCase();
        String contrasena =
                editarContrasena.getText().toString();

        if (correo.isEmpty() || contrasena.isEmpty()) {
            mensaje("Ingresa tu correo y contraseña");
            return;
        }

        botonIngresar.setEnabled(false);

        autenticacion.signInWithEmailAndPassword(
                correo, contrasena
        ).addOnCompleteListener(this, tarea -> {
            botonIngresar.setEnabled(true);

            if (tarea.isSuccessful()) {
                startActivity(new Intent(
                        this, bienvenida.class));
                finish();
            } else {
                mensaje("No se pudo iniciar sesión. "
                        + "Verifica tus datos e inténtalo de nuevo.");
            }
        });
    }

    private void recuperarContrasena() {
        String correo = editarCorreo.getText().toString()
                .trim().toLowerCase();

        if (correo.isEmpty()) {
            mensaje("Escribe tu correo para recuperar la contraseña");
            return;
        }

        autenticacion.sendPasswordResetEmail(correo)
                .addOnCompleteListener(tarea -> {
                    if (tarea.isSuccessful()) {
                        mensaje("Si el correo está registrado, "
                                + "recibirás instrucciones para cambiar "
                                + "tu contraseña");
                    } else {
                        mensaje("No se pudo solicitar la recuperación");
                    }
                });
    }

    private void mensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }
}
