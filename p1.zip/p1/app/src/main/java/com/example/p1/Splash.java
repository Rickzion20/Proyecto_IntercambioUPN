package com.example.p1;

import android.animation.AnimatorSet;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;


public class Splash extends AppCompatActivity {
    private final Handler temporizador =
            new Handler(Looper.getMainLooper());

    private View contenedorLogo;
    private TextView tvUniversidad;
    private TextView tvTitulo;
    private TextView tvEslogan;
    private TextView tvDescripcion;
    private ProgressBar barraCarga;

    private final Runnable abrirLogin = () -> {
        Intent intencion = new Intent(
                Splash.this,
                login.class
        );

        startActivity(intencion);

        overridePendingTransition(
                android.R.anim.fade_in,
                android.R.anim.fade_out
        );

        finish();
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_splash);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        getWindow().setStatusBarColor(Color.rgb(123, 17, 19));
        getWindow().setNavigationBarColor(Color.rgb(123, 17, 19));

        setContentView(R.layout.activity_splash);

        contenedorLogo = findViewById(R.id.contenedorLogo);
        tvUniversidad = findViewById(R.id.tvUniversidad);
        tvTitulo = findViewById(R.id.tvTitulo);
        tvEslogan = findViewById(R.id.tvEslogan);
        tvDescripcion = findViewById(R.id.tvDescripcion);
        barraCarga = findViewById(R.id.barraCarga);

        iniciarAnimaciones();

        temporizador.postDelayed(abrirLogin, 4000);
    }

    private void iniciarAnimaciones() {

        // El logo aparece con un efecto de zoom.
        contenedorLogo.setScaleX(0.5f);
        contenedorLogo.setScaleY(0.5f);
        contenedorLogo.setAlpha(0f);

        AnimatorSet animacionLogo = new AnimatorSet();

        animacionLogo.playTogether(
                ObjectAnimator.ofFloat(
                        contenedorLogo, "scaleX", 0.5f, 1f
                ),
                ObjectAnimator.ofFloat(
                        contenedorLogo, "scaleY", 0.5f, 1f
                ),
                ObjectAnimator.ofFloat(
                        contenedorLogo, "alpha", 0f, 1f
                )
        );

        animacionLogo.setDuration(800);
        animacionLogo.setInterpolator(
                new AccelerateDecelerateInterpolator()
        );
        animacionLogo.start();

        // Los textos aparecen desde abajo.
        animarTexto(tvUniversidad, 300);
        animarTexto(tvTitulo, 700);
        animarTexto(tvEslogan, 1100);
        animarTexto(tvDescripcion, 1400);

        // Aparece el indicador de carga.
        barraCarga.setAlpha(0f);
        barraCarga.animate()
                .alpha(1f)
                .setStartDelay(1600)
                .setDuration(500)
                .start();
    }

    private void animarTexto(View vista, long retraso) {

        vista.setAlpha(0f);
        vista.setTranslationY(45f);

        vista.animate()
                .alpha(1f)
                .translationY(0f)
                .setStartDelay(retraso)
                .setDuration(650)
                .setInterpolator(
                        new AccelerateDecelerateInterpolator()
                )
                .start();
    }

    @Override
    protected void onDestroy() {
        temporizador.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}