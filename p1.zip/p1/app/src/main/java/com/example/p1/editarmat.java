package com.example.p1;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Toast;

public class editarmat extends AppCompatActivity {
    public static Material selected;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_editarmat);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        if (selected == null) {
            finish();
            return;
        }

        cargar(R.id.etTitulo, selected.titulo);
        cargar(R.id.etCategoria, selected.categoria);
        cargar(R.id.etCondicion, selected.condicion);
        cargar(R.id.etDescripcion, selected.descripcion);
        cargar(R.id.etIntercambio, selected.intercambio);

        findViewById(R.id.btnGuardar).setOnClickListener(v -> {
            String titulo = texto(R.id.etTitulo);
            String categoria = texto(R.id.etCategoria);
            String estado = texto(R.id.etCondicion);
            String descripcion = texto(R.id.etDescripcion);
            String intercambio = texto(R.id.etIntercambio);

            if (titulo.isEmpty() || categoria.isEmpty()
                    || estado.isEmpty() || descripcion.isEmpty()) {
                mensaje("Completa los campos obligatorios.");
                return;
            }

            selected.titulo = titulo;
            selected.categoria = categoria;
            selected.condicion = estado;
            selected.descripcion = descripcion;
            selected.intercambio = intercambio;

            mensaje("Publicación actualizada.");
            finish();
        });

        findViewById(R.id.btnEliminar).setOnClickListener(v ->
                new AlertDialog.Builder(this)
                        .setTitle("Eliminar publicación")
                        .setMessage("¿Seguro que deseas eliminar este material?")
                        .setNegativeButton("Cancelar", null)
                        .setPositiveButton("Eliminar", (dialog, which) -> {
                            selected.eliminado = true;
                            mensaje("Publicación eliminada.");
                            finish();
                        })
                        .show());

        findViewById(R.id.btnEditar).setOnClickListener(v ->
                finish());
    }

    private void cargar(int id, String valor) {
        ((EditText) findViewById(id)).setText(valor);
    }

    private String texto(int id) {
        return ((EditText) findViewById(id))
                .getText().toString().trim();
    }

    private void mensaje(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }
}
